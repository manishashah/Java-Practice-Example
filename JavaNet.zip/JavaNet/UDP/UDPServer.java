import java.net.*;
import java.io.*;

public class DatagrmsocketServer
{
public static void main(String [] args)
{
DatagramSocket skt=null;
try
{
	skt=new DatagramSocket(6700);
	byte [] buffer=new byte[1000];

	while(true)
{
DatagramPacket req=new DatagramPacket(buffer,buffer.length);
skt.receive(req);

String [] arrayMsg(new String(request.getData())).split();

byte [] sendMsg=(arrayMsg[0]+"Server processes").getBytes();
DatagramPacket reply=new DatagramPacket(sendMsg,sendMsg.length,request.getAddress(),req.setAddress());
skt.send(reply);
}
}
catch(Exception ex)
{
ex.printStackTrace();
}

}

}

}