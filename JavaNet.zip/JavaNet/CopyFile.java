import java.io.*;

public class CopyFile
{
	public void copyFile(String inputFilename, String outputFilename)
	{
		try
		{
			FileInputStream fpin = new FileInputStream(inputFilename);
			FileOutputStream fpout = new FileOutputStream(outputfilename);
			byte buffer = new byte[8192];
			int length = 0;
			while ((length = fpin.read(buffer, 0, buffer.length)) > 0)
			{
				fpout.write(buffer, 0, length);
			}
			fpout.flush();
			fpout.close();
			fpin.close();
		}
		catch (IOException x)
		{
			System.out.println("Error:" + x);
		}
	}
}
			

