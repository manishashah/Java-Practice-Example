public class Democmd
   {
      public static void main(String[] args)
      {
   	// String[] name = {"test1", "test2", "test3"};
    
         
   	 for ( int i = 0; i < args.length; i++ )
   	 {
   	    System.out.println( args[i] );
   	 }
    
      }
   }