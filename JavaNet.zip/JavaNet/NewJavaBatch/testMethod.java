class testMethod
{
public testMethod(int a,int b)
{
a=2;
b=3;
}
public void calculate()
{
int a=20;
int b=30;

System.out.println(a+b);
}

public static void main(String []args)
{
System.out.println("Displaying the calculate Method*********");
testMethod t1=new testMethod(4,5);
t1.calculate();
//calculate();

}
}