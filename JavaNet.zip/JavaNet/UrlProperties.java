

import java.net.MalformedURLException;
import java.net.URL;

public class UrlProperties {

	public static void main(String []args)
	{
		try {
        String url =
    "https://www.google.co.in/search?q=what+is+query&ie=utf-8&oe=utf-8&gws_rd=cr&ei=PCbyVYjOEpWJuASE5bfICQ";
        URL myUrl = new URL(url);
        System.out.println("Protocol: "+myUrl.getProtocol());
        System.out.println("Host: "+myUrl.getHost());
        System.out.println("Port: "+myUrl.getPort());
        System.out.println("Athority of the URL: "+myUrl.getAuthority());
        System.out.println("Query: "+myUrl.getQuery());
        System.out.println("Reference: "+myUrl.getRef());
    } catch (MalformedURLException ex) {
        ex.printStackTrace();
    }

}
}
