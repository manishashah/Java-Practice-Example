import javax.swing.*;
	
class MyFrame extends JFrame {

JFrame f;
String title;	  
public MyFrame(String title) {
		f=new JFrame();

		setSize(300,200); // default size is 0,0
                this.title=title;		

	  }
	
	  public static void main(String[] args) {
	   MyFrame f1 = new MyFrame("Hello");
	    f1.setVisible(true);
}
	}
