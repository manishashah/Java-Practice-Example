import javax.swing.*;
class SimpleGui extends JFrame{
	SimpleGui(){
                 setSize(400,400); //set frames size in pixels
                 setDefaultCloseOperation(EXIT_ON_CLOSE);
                 JButton but1 = new JButton("Click me");
	    Container cp = getContentPane();//must do this
                 cp.add(but1);
	     show();
            }
     
            public static void main(String[] args){
                 SimpleGui gui = new SimpleGui();                 
                 System.out.println("main thread coninues");
            }}
