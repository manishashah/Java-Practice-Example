
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import javax.swing.*;

public class Login extends JFrame
{
		private JLabel nameLabel;
		private JTextField nameText = new JTextField(10);
		private JLabel ageLabel;
		private JTextField ageText = new JTextField(10);
		private JLabel emailLabel;
		private JTextField emailText = new JTextField(25);
		private JButton submit = new JButton("Submit");
		
		public Login()
		{
			super("Login Form");
			setLayout(new FlowLayout());
			
			nameLabel = new JLabel("Name: ");
			nameLabel.setToolTipText("Enter your name in this 			section.");
			add(nameLabel);
			add(nameText);
			
			ageLabel = new JLabel("Age : ");
			ageLabel.setToolTipText("Enter your age in this 			section.");
			add(ageLabel);
			add(ageText);
			
			emailLabel = new JLabel("Email : ");
			emailLabel.setToolTipText("Enter your email in this 			section.");
			add(emailLabel);
			add(emailText);
			
			add(submit);
		}
		
}
--------------------------------------------------------------------------------------------

import javax.swing.JFrame;


public class LoginTest
{
	public static void main(String[] args)
	{
		Login login = new Login();
		
		login.setVisible(true);
		login.setSize(800, 200);
		login.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
