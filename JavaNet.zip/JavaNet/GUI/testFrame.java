import javax.swing.*;



public class testFrame{
public static void main(String [] args)
{
JFrame frm=new JFrame();
JButton button=new JButton("OK");
frm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
frm.getContentPane().add(button);
frm.setSize(400,300);
frm.setVisible(true);
}
}