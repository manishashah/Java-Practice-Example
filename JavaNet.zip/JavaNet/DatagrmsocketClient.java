import java.io.*;
import java.net.*;

public class DatagrmsocketClient
{
public static void main(String [] args)
{
DatagramSocket skt;

	try{
	skt=new DatagramSocket();
String msg="test message";
byte [] b= msg.getBytes();
InetAddress host=InetAddress.getByName("localhost");
int serverSocket=6788;
DatagramPacket req=new DatagramPacket(b,b.length,host,serverSocket);
skt.send(req);
byte [] buffer=new byte[1000];
DatagramPacket reply=new DatagramPacket(buffer,buffer.length);
skt.receive(reply);
System.out.println(new String(reply.getData()));
skt.close();

	}
catch(Exception ex)
{
ex.printStackTrace();
}

}


}