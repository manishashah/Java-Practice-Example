

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.Iterator;

public class Exercise9 {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		Exercise9 e9 = new Exercise9();
		
		System.out.println("Enter first string array: ");
		String str1 = input.nextLine();
		System.out.println("Enter second string array: ");
		String str2 = input.nextLine();
		if(str1.length() > str2.length()){
			
			//System.out.println(manipulationString1(str1, str2));
			//System.out.println(s1);
			Iterator<String> itr1 = manipulationString1(str1, str2).iterator();
			while(itr1.hasNext()){
				System.out.print(itr1.next());
			}
			System.out.println("\n");
			
			Iterator<String> itr2 = manipulationString2(str1, str2).iterator();
			while(itr2.hasNext()){
				System.out.print(itr2.next());
			}
			System.out.println("\n");
			
			//System.out.println(manipulationString2(str1, str2));
			
			//manipulationString3(str1, str2);
			Iterator<String> itr3 = manipulationString3(str1, str2).iterator();
			while(itr3.hasNext()){
				System.out.print(itr3);
			}
			System.out.println("\n");
		}
	}
	
	public static ArrayList<String> manipulationString1(String str1, String str2){
		
		char c1[] = str1.toCharArray();
		String subStr;
		int last = c1.length;
		System.out.println("I am first Manipulation");
		ArrayList<String> s1 = new ArrayList<String>();
		//System.out.println(last);
		
			//Copy String to ArrayList
			for(int i = 1; i < str1.length(); i += 2){
				s1.add(str2);
				subStr = String.copyValueOf(c1,i,1);
				//System.out.println(subStr);
				s1.add(subStr);
				//System.out.println(s1);
			}
			if (last%2 != 0 ){
				//subStr = String.copyValueOf(c1, --last ,1);
				s1.add(str2);
			}
			return s1;
		}
	
	public static ArrayList<String> manipulationString2(String st1, String st2){
		
		ArrayList<String> newString = new ArrayList<String>();
		String str = "";
		System.out.println("I am second Manipulation");
            if(st1.contains(st2)){
            	//System.out.println(st1.length());
            	//System.out.println(st2.length());
            		int tmp = st1.lastIndexOf(st2);
            		//System.out.println(tmp);
            		//System.out.println(st1.lastIndexOf(st2));
            		
            		str = st1.substring(0,tmp);
            		//System.out.println(str);
            		newString.add(str);
            		String s = reverseString(st2);
            		newString.add(s);
            		tmp += newString.size();
            		//System.out.println(st1.length() + " " + tmp);
            		if(st1.length() > tmp){
            			String s2 = st1.substring(tmp);
            			newString.add(s2);
            		}	
            			//System.out.println(newString);
            		
            }
       		return newString;
            
	}
	
	public static ArrayList<String> manipulationString3(String st1, String st2){
		
		ArrayList<String> newString = new ArrayList<String>();

		System.out.println("I am third Manipulation");
		if(st1.contains(st2)){
			int tmp = st1.indexOf(st2);
			System.out.println(st1);
			String b = st1.substring(0, tmp);
			newString.add(b);
			String a = st1.substring(tmp);
			if(a.equals(st2))
				newString.add(a);
			else{
			System.out.println(a);
	
			System.out.println(st1);
			
				if(a.contains(st2)){
					String s = st1.replaceFirst(st2, "");
					System.out.println(s);
					newString.add(s);
				}
				//System.out.println(st1);
				//newString.add(st1);
			}
		}
		return newString;
	
	}
		
	static String reverse = "";
		
	public static String reverseString(String str){
			if(str.length() == 1){
				//System.out.println(str.length());
				return str;
			}else {
				reverse += str.charAt(str.length() -1) 
						+reverseString(str.substring(0, str.length() -1));
				//System.out.println(str.length());
				return reverse;
			}
	}
}
