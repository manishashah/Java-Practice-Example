/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testproject;

/**
 *
 * @author Admin
 */
public class TestProject {

    void myMethod( int counter)
{
if(counter == 0)
     return;
else
       {
       System.out.println(""+counter);
       myMethod(--counter);
       return;
       }
}
    
    public static void main(String[] args) {
        // TODO code application logic here
    TestProject tp1=new TestProject();
    
    tp1.myMethod(12);
    
    }
    
}
