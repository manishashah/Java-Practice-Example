import java.io.*;
import java.sql.*;

public class OraThin {
  public static void main(String[] args) {
    try {
      Connection con=null;
      Class.forName("oracle.jdbc.driver.OracleDriver");
      con=DriverManager.getConnection(
        "jdbc:oracle:thin:@machine_name:1521:database_name",
        "scott",
        "tiger");
      Statement s=con.createStatement();
      s.execute("
        INSERT INTO BOOKS VALUES 
        (
        'A Tale of Two Cities', 
        'William Shakespeare', 
        4567891231,
        '5-JAN-1962'
        )
      ");
      s.close();
      con.close();
   } catch(Exception e){e.printStackTrace();}
 }
}
