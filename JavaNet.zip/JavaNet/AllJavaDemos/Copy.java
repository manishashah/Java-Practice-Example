import java.io.*;
public class Copy {
public static void main(String[] args) throws Exception
{
    FileInputStream f = new FileInputStream("c:\\MyFile.txt");
    BufferedReader br= new BufferedReader(new InputStreamReader(f));
    String str=br.readLine();
    while(str != null)
    {
    System.out.println(str);
    FileInputStream f2 = new FileInputStream(str);
    BufferedReader br2= new BufferedReader(new InputStreamReader(f2));
    String str2=br2.readLine();
    System.out.println(str2);
    str=br.readLine();
    }
    
}
}
