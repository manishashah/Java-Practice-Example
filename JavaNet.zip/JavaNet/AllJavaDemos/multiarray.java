import java.util.*;

class multiarray
{
public static void main(String[] ax)
{
int[][] a=new int[3][2];
Scanner s=new Scanner(System.in);
for(int r=0;r<3;r++)
{
  for(int c=0;c<2;c++)
   {
   a[r][c]=s.nextInt();    
   }
}

for(int r=0;r<3;r++)
{
  for(int c=0;c<2;c++)
   {
   System.out.println(a[r][c]);
   }
}
}
}