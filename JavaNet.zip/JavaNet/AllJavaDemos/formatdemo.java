/*
 * formatdemo.java
 *
 * Created on June 3, 2009, 1:43 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package sample;

/**
 *
 * @author Administrator
 */
public class formatdemo {
    
    /** Creates a new instance of formatdemo */
    public formatdemo() {
    
    }
    
    public static void main (String ags[])
    {
    int i1=-123;
    
    System.out.printf(">%1$(7d<\n",i1);
    System.out.format("%7d",130);
    }
}
