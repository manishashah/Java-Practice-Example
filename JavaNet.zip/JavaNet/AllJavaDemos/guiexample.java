import java.awt.*;

public class guiexample
{
private Panel p1;
private Panel p2;
private Frame f;
private Button lft,rt,up,dw;

public guiexample()
{
f=new Frame("Direction");
lft=new Button("left");
rt=new Button("right");
up=new Button("up");
dw=new Button("down");
p1=new Panel();
p2=new Panel();

}

public void launchframe()
{
f.setBackground(Color.blue);
f.setLayout(null);
p1.setSize(100,100);
p2.setSize(100,100);
p1.setBackground(Color.red);
p2.setBackground(Color.yellow);
f.add(p1);
f.add(p2);
p1.add(lft,rt);
p2.add(up,dw);
f.setVisible(true);
}


public static void main(String args[])
{
guiexample guiwindow=new guiexample();
guiwindow.launchframe();
}
}