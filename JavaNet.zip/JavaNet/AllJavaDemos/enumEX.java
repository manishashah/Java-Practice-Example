package cards.domain;

public class enumEx
{

public enum Suit{
SPADES,HEARTS,CLUBS,DIMONDS
}
}
