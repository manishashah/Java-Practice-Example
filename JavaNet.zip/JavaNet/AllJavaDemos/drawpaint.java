

package paint2;
import java.awt.*;
import java.awt.event.*;
import java.awt.Graphics;
import java.applet.*;
import java.lang.Math;
import java.util.*;
import java.io.*;

/*<applet code="Main" width=400 Height=400> </applet>*/

     
public class Main extends Applet implements ActionListener, MouseListener,MouseMotionListener
{

Button bLine,bRect,bCircle,bPolygon,bEllipse,bSelect1,bSelect2,bHeading;
String msg="";
int mouseX=0,mouseY=0;
int dots = 0;
boolean mouseUp = false;
boolean Line=false;
boolean Rect = false;
boolean Circle = false;
boolean Polygon = false;
boolean Ellipse = false;
Font font;


public void init()
{

setLayout(null);
font= new Font("Arial", Font.BOLD, 24);
bHeading = new Button("MY PAINT APPLICATION");
bHeading.setSize(500,40);
bHeading.setLocation(300,40);
bHeading.setFont(font);
bHeading.setForeground(Color.white.brighter());

setLayout(null);
bLine = new Button("Line");
bLine.setLocation(40,100);
bLine.setForeground(Color.blue.brighter());
bLine.setFont(new Font("Arial", Font.BOLD, 16));

bRect = new Button("Rectangles");
bRect.setLocation(500,100);
bRect.setForeground(Color.red.brighter());
bRect.setFont(new Font("Arial", Font.BOLD, 16));

bcircle = new Button("Circle");
bcircle.setLocation(300,100);
bcircle.setForeground(Color.green.brighter());
bcircle.setFont(new Font("Arial", Font.BOLD, 16));

bPolygon = new Button("Polygon");
bPolygon.setLocation(900,100);
bPolygon.setForeground(Color.yellow.brighter());
bPolygon.setFont(new Font("Arial", Font.BOLD, 16));

bEllipse = new Button("Ellipse");
bEllipse.setLocation(700,100);
bEllipse.setForeground(Color.blue.brighter());
bEllipse.setFont(new Font("Arial", Font.BOLD, 16));


setLayout(null);
bSelect1 = new Button("SELECT LINE COLOR");
bSelect1.setLocation(220,170);
bSelect1.setForeground(Color.white.brighter());
bSelect1.setBackground(Color.green.brighter());
bSelect1.setFont(new Font("Arial", Font.BOLD, 16));

bSelect2 = new Button("SELECT FILL COLOR");
bSelect2.setLocation(500,170);
bSelect2.setForeground(Color.white.brighter());
bSelect2.setBackground(Color.green.brighter());
bSelect2.setFont(new Font("Arial", Font.BOLD, 16));

add(bLine);
add(bRect);
add(bcircle);
add(bPolygon);
add(bEllipse);
add(bSelect1);
add(bSelect2);
add(bHeading);

bLine.addActionListener(this);
bRect.addActionListener(this);
bCircle.addActionListener(this);
bPolygon.addActionListener(this);
bEllipse.addActionListener(this);
addMouseListener(this);
addMouseMotionListener(this);
}
public void mousePressed(MouseEvent e)
{
mouseX=e.getX();
mouseY=e.getY();
msg="Down";
repaint();
}
public void mouseReleased(MouseEvent e)
{
mouseX=e.getX();
mouseY=e.getY();
mouseUp = true;
repaint();
}
public void mouseDragged(MouseEvent e)
{
mouseX=e.getX();
mouseY=e.getY();       
msg="*";
showStatus("Dragging mouse at"+ mouseX +"," +mouseY);
repaint();
}
public void mouseClicked(MouseEvent e)
{
 mouseX=0;
 mouseY=10;
 msg="mouse Clicked.";
 repaint();
}
public void mouseEntered(MouseEvent e)
{
 mouseX=0;
 mouseY=10;
 msg="mouse entered.";
 repaint();
}
public void mouseExited(MouseEvent e)
{
mouseX=0;
mouseY=10;
}
public void mouseMoved(MouseEvent e)
{
    showStatus("Moving mouse at" + me.getX() +"," + me.getY());
}
public void paint (Graphics g)
{
g.drawString(msg,mouseX,mouseY);
}
}


public void actionPerformed(ActionEvent ae)
{
String str=ae.getActionCommand();
if(str.equals(Line))
{
msg="You pressed Line.";
}
else if(str.equals(Rect))
{
msg="You pressed Rectangle.";
}
else if(str.equals(Circle))
{
msg="You pressed Circle.";
}
else if(str.equals(Polygon))
{
msg="You pressed Polygon.";
}
else (str.equals(Ellipse))
{
msg="You pressed Ellipse.";
}
repaint();



setFlagsFalse();
if(ae.getSource() == bDraw)draw = true;
if(ae.getSource() == bLine)line = true;
if(ae.getSource() == bOval)oval = true;
if(ae.getSource() == bRect)rectangle = true;
if(ae.getSource() == bRounded)rounded = true;
}

void setFlagsFalse()
{
rounded = false;
line = false;
oval = false;
rectangle = false;
draw = false;
}
public static void main(String args[])
{
draw n=new draw();
}


