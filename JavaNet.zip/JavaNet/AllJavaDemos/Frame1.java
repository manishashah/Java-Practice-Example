 import java.awt.*;
 class Frame1
 {
   private Frame f;
   private Panel p;
   public Frame1()
   {
    f  = new  Frame();
    p = new Panel();
   }
  public void launchFrame()
  {
   f.setSize(50,50);
   f.setBackground(Color.BLUE);
   f.add(p);
   p.setSize(100,100);
   p.setBackground(Color.RED);
  } 
 public static void main(String[] args)
 {
  Frame1 p = new Frame1();
  p.launchFrame();
 } 
}