class Student
{

public void disp()
{
System.out.println("This is user defined method");
}
public static void main(String args[])
{
System.out.println("This is my first Java Program output");
Student John=new Student();
John.disp();
}
}
