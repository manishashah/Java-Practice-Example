class argument
{
public static void main (String args[])
{
for(int i=0;i<args.length;i++)
{
System.out.println("The first argument is "+args[i]);
}
}
}