class constructor
{
int x,y;
public constructor()
{
System.out.println("No Parameters");
}
public constructor(int a,int b)
{
this.x=a;
this.y=b;
System.out.println(x);
System.out.println(y);
}
public constructor(double a,double b)
{
System.out.println(a);
System.out.println(b);
}
public static void main (String args[])
{
constructor c1=new constructor();
constructor c2=new constructor(10.0,20.0);

}
}