import javax.swing.*;
import java.awt.*;

public class framedemo extends JFrame
{

public framedemo()
{
JFrame f;
JLabel  l1,l2;
JTextField t1,t2;
JButton b1,b2;

f=new JFrame("Welcome");

l1=new JLabel("Num1");
l2=new JLabel("Num2");
t1=new JTextField(10);
t2=new JTextField(10);
b1=new JButton("Submit");
b2=new JButton("Cancel");

f.getContentPane();
//setLayout(new GridLayout(3,2));

f.add(l1);
f.add(t1);
f.add(l2);
f.add(t2);
f.add(b1);
f.add(b2);
f.setSize(300,400);
f.setVisible(true);

}

public static void main(String args[])
{
framedemo demo=new framedemo();

}
}