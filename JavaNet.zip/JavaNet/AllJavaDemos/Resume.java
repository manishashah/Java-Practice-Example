import java.awt.*;
import javax.swing.*;
import java.awt.Dimension.*;
/*<applet code="Resume.java" width=650 height=600></applet>*/

public class Resume extends JApplet
{
ButtonGroup bg,bg1;
JRadioButton male,female,single,married;
JLabel res,name,phone,mail,dob,add,gender,martial,profdetail,exp,skill,post,currloc,preloc,edu;
JTextField tname,tphone,tpost,tskill,tcurrloc,tmail;

JPanel p=new JPanel();
JTextArea tadd;
JComboBox month,date,year,cexp,cprefloc;

public void init()
{
GridBagLayout g=new GridBagLayout();
GridBagConstraints gb=new GridBagConstraints();

gb.gill=GridBagConstraints.HORIZontal;
p.setLayout(g);
getContentPane().setLayout(new FlowLayout());

res=new JLabel("Resume");
gb.anchor=GridBagConstraints.CENTER;
gb.gridx=0;
gb.gridy=0;
gb.ipady=10;
g.setConstraints(res,gb);
p.add(res);

name=new JLabel("Name");
gb.anchor=GridBagConstraints.CENTER;
gb.gridx=0;
gb.gridy=1;
gb.ipady=10;

g.setConstraints(name,gb);
p.add(name);

tname=new JTextField(10);
gb.anchor=GridBagConstraints.CENTER;
gb.gridx=2;
gb.gridy=1;
g.setConstraints(tname,gb);
p.add(tname);

add=new JLabel("Address");
gb.anchor=GridBagConstraints.CENTER;
gb.gridx=0;
gb.gridy=2;
gb.ipady=25;
g.setConstraints(add,gb);
p.add(add);

tadd=new JTextArea(2,10);
gb.anchor=GridBagConstraints.CENTER;
gb.gridx=2;
gb.gridy=2;
gb.ipady=1;
g.setConstraints(tadd,gb);
p.add(tadd);

phone=new JLabel("Phone no:");
gb.anchor=GridBagConstraints.CENTER;
gb.gridx=0;
gb.gridx=3;
gb.ipady=20;
g.setConstraints(phone,gb);
p.add(phone);

tphone=new JTextField(10);
gb.anchor=GridBagConstraints.CENTER;
gb.gridx=2;
gb.gridy=3;
gb.ipady=5;
g.setConstraints(tphone,gb);
p.add(tphone);

dob=new JLabel("Birthdate [dd/mm/yy]");
gb.anchor=GridBagConstraints.CENTER;
gb.gridx=0;
gb.gridy=4;
gb.ipady=20;
g.setConstraints(dob,gb);
p.add(dob);

date=new JComboBox();
for(int j=1;j<=32;j++)
date.addItem(""+j);
gb.anchor=GridBagConstraints.NORTHWEST;
gb.gridx=2;
gb.gridy=4;
gb.ipady=1;
g.setConstraints(date,gb);
p.add(date);

month=new JComboBox();
for(int j=1;j<13;j++)
month.addItem(""+j);
gb.anchor=GridBagConstraints.NORTHWEST;
g


//all the same stuff

JPanel into=new JPanel();

String [] col={"Examination","Board","Year","Percentage"};

String [][] date={{"ssc","Maharashtra","2001"},
{"ssc","Maharashtra","2001"},
{"ssc","Maharashtra","2001"},
{"ssc","Maharashtra","2001"},}

JTable t=new JTable(data,col);
JScrollPane j=new JScrollPane();
j.setPreferredSize(new Dimension(450,85));
getContentPane().add(j);
}
}


}
}
