import java.awt.*;
import javax.swing.*;

public class ColorEx extends JApplet
{
public void paint ( Graphics g )
{
g.setColor( Color.RED );
g.drawString ( "Hello World", 0,12 );
g.setColor( Color.BLUE );
g.drawString ( "Java rocks", 0,50 );
g.setColor( Color.CYAN );
g.fillRect ( 50,60,40,20 );
}
}