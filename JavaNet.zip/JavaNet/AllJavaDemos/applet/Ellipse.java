import java.awt.*; // access the Graphics object
import javax.swing.*; // access to JApplet
public class Ellipse extends JApplet
{
public void paint( Graphics g )
{
g.drawOval( 0,0, 100, 10 );
}
}