import java.awt.*;
import javax.swing.*;


public class ColorEx1 extends JApplet
{
public void paint ( Graphics g )
{
g.setColor( new Color( 130, 130, 80 ) );
g.drawString ( "Hello World", 0,12 );
g.setColor( new Color( 128, 0, 128 ) );
g.drawString ( "Java rocks", 0,50 );
g.drawString ( "Rockin' to the music", 10,70 );
}
}