import java.awt.*; // access the Graphics object
import javax.swing.*; // access to JApplet
public class Square extends JApplet
{
public void paint ( Graphics g )
{
g.drawRect ( 0,0, 20, 20 );
}
}