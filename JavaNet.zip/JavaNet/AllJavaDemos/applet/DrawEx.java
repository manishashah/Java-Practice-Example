import java.awt.*; 
import javax.swing.*; 

public class DrawEx extends JApplet
{

public void paint( Graphics g )

{


}
}