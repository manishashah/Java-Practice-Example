import javax.swing.*;
import java.awt.*;
public class PolyEx2 extends JApplet
{
public void paint( Graphics g )
{
Polygon pg = new Polygon( );
pg.addPoint( 10, 10 );
pg.addPoint( 50, 100 );
pg.addPoint( 10, 30 );
pg.addPoint( 50, 10 );
pg.addPoint( 70, 80 );
g.drawPolygon( pg );
}
}