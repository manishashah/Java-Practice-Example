import java.awt.*; // access the Graphics object
import javax.swing.*; // access to JApplet
public class Shapes extends JApplet
{
public void paint ( Graphics g )
{
g.setColor( Color.GREEN );
g.fillOval( 0,0, 100, 10 );
g.setColor( Color.BLUE );
g.drawRect( 0,0, 20, 20 );
g.drawRect ( 10,10, 20, 20 );
g.drawRect ( 20,20, 20, 20 );
g.drawOval ( 30, 30, 20, 20 );
}
}