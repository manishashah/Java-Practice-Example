import javax.swing.*;
import java.awt.*;
public class ImageEx extends JApplet
{
public void paint( Graphics g )
{
Image img = getImage( getCodeBase( ), "Lion.jpg" );
g.drawImage( img, 0,0, this );
}
}