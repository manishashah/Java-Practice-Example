class demo
{
int id;
public demo(int i)
{
id=i;
}

public String toString()
{
return "id is"+id;
}

public static void main(String args[])
{
demo d1=new demo(30);
demo d2=new demo(20);
System.out.println(d1);
System.out.println(d2);
}
}