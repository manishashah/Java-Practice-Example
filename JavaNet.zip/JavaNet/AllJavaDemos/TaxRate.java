class Taxservice
{
public TaxRate findTaxRate(Employee e)
{
System.out.println("Tax for employee" + employee +"is:" );
return TaxRate;
}

}
public class TaxRate 
{
//public rate;

public static void main(String args[])
{
Taxservice  taxSvc = new Taxservice();
}
}
class Employee
{



}



