import javax.swing.*;

class Picture
{
         JFrame f;
         JPanel p;
         JLabel l;
	
	public Picture()
	{
	    f = new JFrame("picture frame");
	    p=new JPanel();
	l=new JLabel();

	f.getContentPane().add(p);
	l.setIcon(new ImageIcon("C:\\Documents and Settings\\All Users\\Documents\\My Pictures\\Sample Pictures\\Sunset.jpg"));
		p.add(l);
	f.setSize(200,200);
	f.setVisible(true);
	
	}
	public static void main(String args[])
	{
	Picture k =new Picture();
	}
}