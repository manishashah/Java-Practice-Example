import java.awt.*;
import java.awt.event.*;

class Loginframe extends Frame implements ActionListener
{
	Frame f,
	Panel p1;
	Label l1,l2;
	TextField t1,t2;
	Button b1,b2,b3;
	
	public Loginframe()
	{
	super("Login Frame");
	setBounds(50,50,300,300);
	setLayout(new GridLayout(1,2));
	p1=new Panel();
	p1.setLayout(new FlowLayout(0));
	p1.setBackground(Color.magneta);
	l1=new Label("User Name");
	t1=new TextField(20);
	l2=new Label("Password");	
	t2=new TextField(10);
	b1=new Button("OK");
	b2=new Button("Cancel");
	b3=new Button(New User);
	b1.addActionListener(this);
	b2.addActionListener(this);
	b3.addActionListener(this);
	p1.add(l1);
	p1.add(t1);
	p1.add(l2);
	p1.add(t2);
	p1.add(b1);
	p1.add(b2);
	p1.add(b3);
	add(p1);
	t1.getText();
	t2.setEchoChar('*');
	show();
	}

public static void main(String args[])	
{
Loginframe lf=new Loginframe();

}
}


