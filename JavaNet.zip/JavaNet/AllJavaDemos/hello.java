import java.io.*;

public class hello
{

public static void main (String args[]) throws IOException
{
InputStreamReader ir=new InputStreamReader(System.in);
BufferedReader br=new BufferedReader(ir);

String s=br.readLine();
System.out.println(s);

}
}