public class pyramid
{

public static void main(String args[])
{
String space=" ";


for(int i=0;i<=3;i++)
{
System.out.println("*");
for(int j=0;j<3-i;j++)
{
System.out.println("*");
}
//System.out.println(" ");
}
}
}