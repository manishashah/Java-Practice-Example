import java.awt.*;

public class login
{
private Frame f;
private Button b1;
private Button b2;
private Label l1;
private Label l2;
private Textfield t1;
private Textfield t2;
}

public login()
{
f=new Frame("login");
b1=new Button("Submit");
b2=new Button("cancle");
l1=new Label("Username");
l2=new Label("Password");
}

public void launchFrame()
{
f.setLayout(new GridLayout(3,2));
f.setSize(400,400);
f.setBackground(Color.blue);


f.add(l1);
f.add(t1);
f.add(l2);
f.add(t2);
f.add(b1);
f.add(b2);

f.setVisible(true);
}

public static void main(String args[])
{
login log=new login();
log.launchFrame();
}
}

