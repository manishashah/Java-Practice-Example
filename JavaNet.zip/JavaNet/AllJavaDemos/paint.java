import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class paint implements ActionListener
{
    Frame f;
    Button bHeading;
    Button bRectangle;
    Button bCircle;
    Button bPolygon;
    Button bEllipse;
    Button bLine;
    MenuBar mb;
    Menu file,edit;
    MenuItem n1,open,sv,saveas;
    Panel p;
    
    
    public paint()
    {  
    f=new Frame();
   //f.setLayout(null);
  //font f1=new Font("ArialBlack",Font.BOLD,25);
    bHeading=new Button("MY PAINT APPLICATION");
    bHeading.setSize(400,40);
    bRectangle=new Button("Rectangle");
    bRectangle.setSize(100,40);
    bCircle=new Button("Circle");
    bCircle.setSize(100,40);
    bPolygon=new Button("Polygon");
    bPolygon.setSize(100,30);
    bEllipse=new Button("Ellipse");
    bEllipse.setSize(100,30);
    bLine=new Button("Line");
    bLine.setSize(100,40);
    p=new Panel();
    mb=new MenuBar();
    file=new Menu("File");
    edit=new Menu("Edit");
    n1=new MenuItem("new");
    open=new MenuItem("open");
    sv=new MenuItem("save");
    saveas=new MenuItem("saveas");
   f.setMenuBar(mb);
    f.add(p);
    mb.add(file);
    mb.add(edit);
    file.add(n1);
    file.add(open);
    file.add(sv);
    file.add(saveas);
   
    p.add(bHeading);
    p.add(bRectangle);
    p.add(bCircle);
    p.add(bPolygon);
    p.add(bEllipse);
    p.add(bLine);
    bRectangle.addActionListener(this);
    bCircle.addActionListener(this);
    bPolygon.addActionListener(this);
    bEllipse.addActionListener(this);
    bLine.addActionListener(this);
    //addMouseListener(this);
    //p.add(b);
    
    f.setSize(500,500);
    f.setVisible(true);
    }
    public void actionPerformed(ActionEvent ae)
    {
    }
    
    public static void main(String[] args) 
    {
     paint p1=new paint();
     }
    
}
