import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class chemf extends JFrame 
{
  JFrame f;
  JTextField t1,t2;
  JLabel l1,l2;
  JButton b1,b2;
  public chemf()
  {
    f=new JFrame("Chemical Formula");
    l1=new JLabel("First Comp");
    t1=new JTextField(10);
    l2=new JLabel("Second Comp");
    t2=new JTextField(10);
    b1=new JButton("Result");
    b2=new JButton("Exit");
    getContentPane().add(f);
    f.add(l1);
    
 }
  public static void main(String args[])
  {
     chemf ch=new chemf();
     ch.setVisible(true);
     ch.setSize(500,500);
  }
}