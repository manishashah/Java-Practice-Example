import java.io.*;
import java.util.*;
class formatdemo
{
public static void main (String args[])
{
int total=890;
String user="Rogger";
}
}