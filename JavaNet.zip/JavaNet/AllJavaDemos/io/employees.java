import java.sql.*;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.Connection;

public class employees
{
	public static void main(String args[])
	{
	try {
                    Connection con=null;
                  Class.forName("oracle.jdbc.driver.OracleDriver");
      con=DriverManager.getConnection(
        "jdbc:oracle:thin:@localhost:1521:oracle9i",
        "hr",
        "hr");
//DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
                         
                        
      Statement stmt=con.createStatement();
	String str="SELECT employee_id, last_name, manager_id FROM employees WHERE last_name LIKE '%c%'";
                        /*1.Initialize and load the JDBC-ODBC Bridge driver*/
	
		
                ResultSet rs=stmt.executeQuery(str);
			System.out.println("Employee ID \t Last Name\t\t Manager ID");
			/*5Display the result*/
		
                        while (rs.next())
			{
				int employee_id=rs.getInt("employee_id");
				String last_name=rs.getString("last_name");
//				String fname=rs.getString("au_fname");
				int manager_id=rs.getInt("manager_id");
                                System.out.println(employee_id+"\t"+last_name+"\t\t"+manager_id);
                                
				/*Use tab to format the output. If the number of characters in a data value are less than or equal to 7, the two tabs are used to specify the position to display the next column in the ResultSet*/
		/*		if (id.length() <=7) 
					System.out.print(employee_id+"\t\t");
				else 
					System.out.print(employee_id+"\t");
				if (fname.length() <=7) 
					System.out.print(last_name+"\t\t");
				else 
					System.out.print(last_name+"\t");
//				if (lname.length() <=7)
//					 System.out.print(lname+"\t\t");
//				else 
//					System.out.print(lname+"\t");
					System.out.println(manager_id);*/
			} 
			stmt.close();	
			con.close();
		}
		catch(SQLException ex)
		{
			System.out.println("Error occurred");
			System.out.println("Error:"+ex);
		}
	}
}
