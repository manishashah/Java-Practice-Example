class test
{
    enum  rainbowcolor {white,yellow,black}
rainbowcolor color;
}
public class demoenum
{ 
 public static void main(String args[])
{
   test t1=new test();
   t1.color=test.rainbowcolor.yellow;
   System.out.println(t1.color);
}
}