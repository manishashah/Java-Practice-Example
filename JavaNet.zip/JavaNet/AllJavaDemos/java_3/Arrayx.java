class Arrayx
{
	public static void main(String [] args)
	{
		String week[][] = new String[2][2];
		int i,j;
		int k=0;
		for(i=0;i<2;i++)
		{
			for(j=0;j<2;j++)
			{
				week[i][j] = args[k];
				k++;
				System.out.print("\t" + week[i][j] );
			}
			System.out.println("");
		}
	}
}
/*
sun	mon
tue	wed
*/