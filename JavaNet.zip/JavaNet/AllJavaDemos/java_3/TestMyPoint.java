class MyPoint
{
public int x;
public int y;

public MyPoint(int a,int b)
{
x=a;
y=b;
}

public String toString()
{
return "["+x+","+y+ "]";
}

}

class TestMyPoint
{
public static void main(String a[])
{
MyPoint start=new MyPoint(10,10);
MyPoint stray=new MyPoint(47,50);
MyPoint end=new MyPoint(20,30);
System.out.println("Start Point is "+start);
System.out.println("End Point is "+end);
System.out.println("");

System.out.println("Stray Point is "+stray);
System.out.println("End Point is "+end);
System.out.println("");

System.out.println("Stray Point is "+stray);
System.out.println("End Point is "+end);
System.out.println("Start Point is "+start);
}
}