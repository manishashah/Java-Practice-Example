class array1
{

public char[] creatArray()
{
char[] s;

s=new char[26];
for(int i=0;i<26;i++)
{
s[i]=(char)('A'+i);
}
return s;
}

public static void main(String args[])
{
array1 r=new  array1();
System.out.println(r.creatArray());

}
}