class demo
{
public void disp()
{
int id[];
id=new int [3];
id[0]=1;
id[1]=2;
id[2]=3;
for(int val=0;id<=3;val++)
{
System.out.println(val);
}
}
public static void main (String a[])
{
demo d=new demo();
d.disp();
}
}
}