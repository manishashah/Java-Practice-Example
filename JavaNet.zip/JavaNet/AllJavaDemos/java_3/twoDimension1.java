public class twoDimension1{

  public static void main(String[] args)
 {
 int[][] a2 = new int[7][4];
  for (int i=0; i<=3; i++) 
   {
      for (int j=0; j<=i; j++)
      {
        a2[i][j] = i;
        System.out.print(" " + a2[i][j]);
      }
System.out.println("");	  
 
    }
for(int i=4;i<7;i++)
{
for(int j=0;j<7-i;j++)
{
a2[i][j]=i;
System.out.print(" " + a2[i][j]);
}
System.out.println("");
}

 }

  }
