class onedimension
{

public static void main(String args[])
{
//int x[]=;
int[] x=new int[]{1,2,3,4,5,6};
/*x[0]=34;
x[1]=23;
x[2]=12;
x[3]=6;
*/
for(int i=0;i<6;i++)
{
System.out.print(x[i]+"\t" );
//System.out.println(" ");
}

}

}