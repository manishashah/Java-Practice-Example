class copy
{
static int[] myArray = { 11,22,33,44,55,66};

 // new larger array
static int[] hold = { 10, 9, 8, 7, 6, 5, 4, 3, 2, 1 };

 // copy all of the myArray array to the hold
 // array, starting with the 0th index
public static void main(String args[])
{ 
System.out.println("Elements of myArray before copy");
for(int i=0;i<myArray.length;i++)
{
System.out.println(myArray[i]);
}
System.out.println("Elements of hold before copy");
for(int j=0;j<hold.length;j++)
{
System.out.println(hold[j]);
}
System.arraycopy(myArray, 0, hold, 0, myArray.length);
System.out.println("Elements of myArray");
for(int i=0;i<myArray.length;i++)
{
System.out.println(myArray[i]);
}
System.out.println("Elements of hold");
for(int j=0;j<hold.length;j++)
{
System.out.println(hold[j]);
}
}
}