class newfor
{
public static void main (String a[])
{

for(int i:a[])
{
System.out.println(i);
}

}
}