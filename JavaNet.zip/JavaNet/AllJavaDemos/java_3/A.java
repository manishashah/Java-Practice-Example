class C
{
protected int val=10;
public int getVal()
{
return val;
}
public int display()
{
System.out.println("This is C's method");
return val;
}
}
class B extends C
{
public void display()
{
C c2=new C();
System.out.println("This is B's method");
System.out.println(val);
//System.out.println(c2.getVal());
}
}
class A extends C
{
public void display()
{
System.out.println("This is A's method");
System.out.println(val);
}

public static void main(String args[])
{
C c1=new C();
c1.display();
B b1=new B();
b1.display();
A a1=new A();
a1.display();

}
}
