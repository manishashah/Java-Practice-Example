class demo
{
public void disp()
{
int id[];
id=new int [3];
id[0]=1;
id[1]=2;
id[2]=3;
for(int i:id)
{
System.out.println(i);
}
	}
public static void main(String a[])
{
demo d=new demo();
d.disp();
}
}
