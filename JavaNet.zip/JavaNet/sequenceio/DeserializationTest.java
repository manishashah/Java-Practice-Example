//DeSerialization
import java.io.*;
class studentinfo implements Serializable 
{
 String name;
 int rid;
 static String contact;
 studentinfo(String n, int r, String c)
 {
  this.name = n;
  this.rid = r;
  this.contact = c;
 }

studentinfo()
{
this.name=name;
this.rid=rid;
this.contact = contact;
}
}

class DeserializationTest
{
 public static void main(String[] args)
 {
  studentinfo si=null ;
  try  
  {
   FileInputStream fis = new FileInputStream("student.ser");
   ObjectOutputStream ois = new ObjectOutputStream(fis);
   si = (studentinfo)ois.readObject();
  } 
  catch (Exception e)
   { e.printStackTrace(); }
  System.out.println(si.name);
  System.out. println(si.rid);
  System.out.println(si.contact);
 }
}